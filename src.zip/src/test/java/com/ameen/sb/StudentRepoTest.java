package com.ameen.sb;

import com.ameen.sb.data.Guardian;
import com.ameen.sb.data.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRepoTest {
    @Autowired
    StudentRepo studentRepo;

    @Test
    public void saveStudent(){
        Student s = Student.builder().age(20).id(2).firstName("Mo").lastName("am").mobile("9878").mailId("ameq@gmail.com").guardian(Guardian.builder().name("shahul").mail("shahul@gmail").phone("12345").build()).build();
        studentRepo.save(s);
    }
}