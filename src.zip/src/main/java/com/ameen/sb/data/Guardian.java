package com.ameen.sb.data;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@AttributeOverrides({@AttributeOverride(name = "name", column = @Column(name = "guardian_name")),
        @AttributeOverride(name = "mail", column = @Column(name = "guardian_mail")),
        @AttributeOverride(name = "phone", column = @Column(name = "guardian_phone"))})
public class Guardian {
    private String name;
    private String mail;
    private String phone;
}
