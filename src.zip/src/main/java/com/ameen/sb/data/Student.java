package com.ameen.sb.data;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Table(name = "csy_student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private int id;

    private String firstName;
    private String lastName;
    @Column(name = "email", nullable = false, unique = true )
    private String mailId;
    private String mobile;
    private int age;

    @Embedded
    private Guardian guardian;
}
